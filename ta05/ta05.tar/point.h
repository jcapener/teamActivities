#ifndef POINT_H
#define POINT_H

class Point
{
   private:
      int x;
      int y;

   public:
      void display() const;

      //POINT :: SET X :
      void setX(int & x)
      {
         if (x < 1)
            this->x = 1;
         else if (x > 10)
            this->x = 10;
         else
            this->x = x;
      }

      //POINT :: SET Y :
      void setY(int & y)
      {
         if (y < 1)
            this->y = 1;
         else if (y > 10)
            this->y = 10;
         else
            this->y = y;
      }
      int getX() const {return x;}
      int getY() const {return y;}

      void display() const;
};

#endif
