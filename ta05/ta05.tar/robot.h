#ifndef ROBOT_H
#define ROBOT_H

#include "point.h"

class Robot
{
   private:
      Point position;
      int energy;

   public:

      //ROBOT :: SET POSITION :
      void setPosition(Point & position)
      {
         if (p >= 1 && p <= 10)
            this->position = position;
      }

      //ROBOT :: SET ENERGY :
      void setEnergy(int & energy)
      {
         if (energy > 0)
            this->energy = energy;
         else
            this->energy = 0;
      }

      Point getPosition() const {return position;}
      int   getEnergy()   const {return energy;  }

      void display() const;

};

#endif
